#!/usr/bin/env python3
"""Chromium regression for direct-save fallback messaging.
Actual app HTML/event handler; deterministic injected handle metadata only.
No native picker, native FSA, or physical disk access is claimed.
"""
from __future__ import annotations
import hashlib, json, platform, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

HERE=Path(__file__).resolve().parent
HTML_PATH=HERE/'raqee3-v8.0.0-rc3-dev-racefix2.html'
HTML_BYTES=HTML_PATH.read_bytes()
HTML=HTML_BYTES.decode('utf-8')
HTML_SHA256=hashlib.sha256(HTML_BYTES).hexdigest()
BASELINE_HTML_PATH=HERE/'raqee3-v8.0.0-rc3-dev-racefix.html'
BASE=BASELINE_HTML_PATH.read_text(encoding='utf-8')
PRELUDE=r'''<script>
window.confirm=()=>true;
window.__mkFile=(name,text,sizeOverride,failArrayBuffer)=>({
 name, size:sizeOverride===undefined?new TextEncoder().encode(text).length:sizeOverride,
 arrayBuffer:async function(){ if(failArrayBuffer) throw new Error('INJECTED_BACKUP_READ_FAILURE'); return new TextEncoder().encode(text).buffer; }
});
</script>'''

def run_case(browser, html, case_id, save_mode='direct'):
 page=browser.new_page(); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(PRELUDE+html,wait_until='domcontentloaded',timeout=30000)
 page.evaluate('''(arg)=>{
   const text=PATCHES[0].steps[0].find;
   currentHtml=text; currentFileName='target.txt'; currentLineEnding='\\n'; currentLineEndings=[];
   currentEncoding='utf-8'; currentHasBOM=false; directOpenedSnapshot=text;
   currentTargetLoadToken=101; currentTargetRawToken=202;
   currentTargetRawEvidence={name:'target.txt',size:new TextEncoder().encode(text).length,sha256:null,token:202,targetEngineVersion:null};
   currentTargetRawHashPromise=Promise.resolve(null);
   directFileName=''; directTargetMatches=false; directFileHandle=null; directWriteBusy=false;
   document.querySelector('input[name="saveMode"][value="'+arg.mode+'"]').checked=true;
   document.getElementById('applyBtn').disabled=false;
   if(arg.kind==='mismatch'){
     directFileHandle={name:'other.txt'}; directFileName='other.txt'; directTargetMatches=false;
   } else if(arg.kind==='stale'){
     directFileHandle={name:'target.txt'}; directFileName='target.txt'; directTargetMatches=true;
     currentTargetRawEvidence=null;
   } else if(arg.kind==='too-large'){
     directFileHandle={name:'target.txt',getFile:async()=>window.__mkFile('target.txt',text,10*1024*1024+1,false),createWritable:async()=>{throw new Error('MUST_NOT_WRITE')}};
     directFileName='target.txt'; directTargetMatches=true;
   } else if(arg.kind==='backup-fail'){
     let getN=0;
     directFileHandle={name:'target.txt',getFile:async()=>{getN++; return window.__mkFile('target.txt',text,undefined,getN===2);},createWritable:async()=>{throw new Error('MUST_NOT_WRITE')}};
     directFileName='target.txt'; directTargetMatches=true;
   }
 }''',{'kind':case_id,'mode':save_mode})
 page.locator('#applyBtn').click()
 page.wait_for_function("document.getElementById('downloadLink').style.display === 'block'",timeout=15000)
 page.wait_for_timeout(80)
 result=page.evaluate('''()=>({
   summary:document.getElementById('summary').innerText,
   toast:document.getElementById('toast').innerText,
   linkVisible:document.getElementById('downloadLink').style.display==='block',
   linkDownload:document.getElementById('downloadLink').download,
   busy:directWriteBusy,
   history:(runHistory||[]).slice(-1)[0]||null,
   evidence:(typeof evidenceGetQueue==='function'?evidenceGetQueue().slice(-1)[0]:null),
   directHandle:!!directFileHandle,
   directName:directFileName,
   targetName:currentFileName
 })''')
 # Direct-mode fallbacks must preserve a warning; ordinary download mode must preserve success.
 status=(result.get('evidence') or {}).get('saveStatus','')
 link=result['linkVisible'] and bool(result['linkDownload'])
 if case_id=='normal-download':
  assertions={
    'normal_download_link_created':link,
    'normal_download_success_summary':('✅ جاهز للتنزيل' in result['summary']),
    'normal_download_success_toast':('✅ الملف جاهز للتنزيل' in result['toast']),
    'busy_released':not result['busy'],
    'no_page_errors':not errors
  }
 else:
  warn=('⚠️' in result['summary']) and ('⚠️' in result['toast'])
  not_success=('✅ جاهز للتنزيل' not in result['summary']) and ('✅ الملف جاهز للتنزيل' not in result['toast'])
  expected_status=(('fallback' in status) or ('cancelled' in status) or ('blocked' in status) or ('failed' in status))
  assertions={
      'fallback_link_created':link,
      'summary_remains_warning':warn,
      'no_false_download_success_message':not_success,
      'evidence_records_non_direct_outcome':expected_status,
      'busy_released':not result['busy'],
      'no_page_errors':not errors
  }
 result.update({'case_id':case_id,'page_errors':errors,'assertions':assertions})
 result['pass_count']=sum(bool(v) for v in result['assertions'].values())
 result['check_count']=len(result['assertions'])
 result['passed']=result['pass_count']==result['check_count']
 page.close(); return result

def main():
 cases=['no-handle','mismatch','stale','too-large','backup-fail']
 allruns=[]; baseline_runs=[]; versions=[]
 for run in range(1,4):
  with sync_playwright() as p:
   b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-first-run'])
   versions.append(b.version)
   results=[run_case(b,HTML,c) for c in cases]
   results.append(run_case(b,HTML,'normal-download','download'))
   baseline=[run_case(b,BASE,c) for c in cases[:4]]
   b.close()
  allruns.append({'run':run,'cases':results})
  baseline_runs.append({'run':run,'cases':baseline})
 source_after=HTML_PATH.read_bytes()
 out={'test_id':'DIRECT-FB-01-RACEFIX2-CHROMIUM','browser':{'name':'Chromium','version':versions[0]},
      'source':{'file':HTML_PATH.name,'size_bytes':len(HTML_BYTES),'sha256_before':HTML_SHA256,'sha256_after':hashlib.sha256(source_after).hexdigest(),'unchanged_during_test':source_after==HTML_BYTES},
      'independent_browser_processes':3,'case_count_per_process':len(cases)+1,
      'case_executions':sum(len(r['cases']) for r in allruns),
      'assertions_passed':sum(c['pass_count'] for r in allruns for c in r['cases']),
      'assertions_total':sum(c['check_count'] for r in allruns for c in r['cases']),
      'passed_cases':sum(c['passed'] for r in allruns for c in r['cases']),
      'total_cases':sum(len(r['cases']) for r in allruns),
      'test_model':'Actual app HTML in Chromium; injected in-memory handle metadata; no native FSA or physical disk.',
      'baseline_before_fix':{'source_sha256':hashlib.sha256(BASE.encode('utf-8')).hexdigest(),'cases':baseline_runs,
        'warning_failures':sum(not c['passed'] for r in baseline_runs for c in r['cases']),
        'warning_cases':sum(len(r['cases']) for r in baseline_runs)},
      'all_observations':allruns}
 (HERE/'DIRECT-FB-01-result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:v for k,v in out.items() if k!='all_observations'},ensure_ascii=False,indent=2))
 for r in allruns:
  for c in r['cases']:
   if not c['passed']: print('FAIL',r['run'],c['case_id'],c['summary'],c['toast'],c['assertions'],file=sys.stderr)
 return 0 if out['assertions_passed']==out['assertions_total'] and out['source']['unchanged_during_test'] else 1
if __name__=='__main__': raise SystemExit(main())
