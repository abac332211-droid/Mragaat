# DIRECT-02 — Native File System Access manual acceptance test

## Purpose and boundary

This kit is for a **desktop Chrome or Edge session with real local files**. It exercises the Raqee3 candidate's actual `FileSystemFileHandle` objects obtained through the browser's real file picker. The helper does not replace `showOpenFilePicker()` or fabricate file handles. It wraps selected handle/writer methods only to introduce controlled pauses and optional injected failures.

Run this only with the two disposable fixture files supplied in this kit. Do not select production files or valuable documents. The helper includes a command that writes the original A bytes back to the test file between cases.

## Files

- `raqee3-v8.0.0-rc3-dev-racefix2.html` — candidate under test.
- `index.html` — 949-byte target fixture; matches the one default test patch and has the expected filename `index.html`.
- `B.txt` — 51-byte sentinel; must never be changed by a transaction that began on A.
- `NATIVE-FSA-DIRECT-02-harness.js` — DevTools helper.

## Browser setup

1. Extract these files into one folder on a desktop computer with current Chrome or Edge.
2. Open a terminal in that folder and start a local server:

   ```bash
   python -m http.server 8000
   ```

3. In the browser, open `http://localhost:8000/raqee3-v8.0.0-rc3-dev-racefix2.html`.
   `localhost` is a secure context for this API. Do not use an `http://` remote LAN address; use HTTPS if testing from a remote origin.
4. In Raqee3, select **direct save**. Use the app's real **open for direct editing** button and select `index.html`.
5. Open DevTools → Console and paste the complete contents of `NATIVE-FSA-DIRECT-02-harness.js` once.
6. Capture A in the console:

   ```js
   await __Raqee3NativeFSA.capture('A')
   ```

   Expected: `name=index.html`, `size=949`, original SHA-256 `1e32bcc37093e4248951245d92354805ed105172c8a1c50811981cbf6b5ac87b`, and expected patched SHA-256 `17b5deb059dbe0a73cc7828b106113242c91aeda4879a14305c63cfc9bacc83c`.

7. Use the app's real picker to select `B.txt`, then capture it:

   ```js
   await __Raqee3NativeFSA.capture('B')
   ```

   Expected B size is 51 bytes and SHA-256 is `7402f922922028f2963ed0ed380a7fd65b82529d9b67a67413bd2403cf4800dd`. B is captured only as an untouched sentinel; the helper does not try to apply the A patch to B.

8. Use the app's real picker once more to select A. In the console, run:

   ```js
   __Raqee3NativeFSA.selectState('A')
   ```

   Both native handles are now retained by the helper. Confirm that the page still reports `directFileName=index.html` before each test.

## Running one race case

For each case below:

1. Restore the original A bytes before starting a new case:

   ```js
   await __Raqee3NativeFSA.restoreOriginalA()
   __Raqee3NativeFSA.selectState('A')
   ```

2. Arm the chosen pause in the Console. Examples:

   ```js
   await __Raqee3NativeFSA.arm('write')
   ```

3. Click Raqee3's **Apply** button manually in the page. This preserves the browser's real user gesture and uses the real native file handle.
4. In Console, wait until the selected native method is suspended:

   ```js
   await __Raqee3NativeFSA.waitUntilPaused()
   ```

5. While it is paused, either test the UI guards:

   ```js
   __Raqee3NativeFSA.tryUiMutations()
   ```

   or force the global target state to the previously captured native B handle:

   ```js
   __Raqee3NativeFSA.forceTarget('B')
   ```

6. Release the suspended native operation and wait for the app's transaction to finish:

   ```js
   __Raqee3NativeFSA.release()
   await __Raqee3NativeFSA.waitUntilIdle()
   await __Raqee3NativeFSA.inspect()
   ```

The inspection reads both files back from their real native handles and reports their sizes and SHA-256 values.

## Acceptance matrix

Run at least these cases, using disposable fixtures only:

| Case | Arm command | During pause | Expected A | Expected B |
|---|---|---|---|---|
| Native freshness read | `arm('freshness-buffer')` | `forceTarget('B')` | Original; cancelled before first write | Original |
| Native backup read | `arm('backup-buffer')` | `forceTarget('B')` | Original; cancelled before first write | Original |
| Native `createWritable` | `arm('createWritable')` | `forceTarget('B')` | Original; writer not used | Original |
| Native post-write readback | `arm('postwrite-buffer')` | `forceTarget('B')` | Patched and byte-verified | Original |
| Native `write()` pending | `arm('write')` | `forceTarget('B')` | Patched and byte-verified | Original |
| Native `close()` pending | `arm('close')` | `forceTarget('B')` | Patched and byte-verified | Original |
| Injected partial stream-write failure | `arm('write-fail')` | `forceTarget('B')` | Original after verified rollback | Original |
| Injected close failure after real commit | `arm('close-after-commit-fail')` | `forceTarget('B')` | Original after verified rollback | Original |

For UI guard cases, use `tryUiMutations()` while paused instead of forcing B. It attempts the real app's picker/input/clear/clean/undo event handlers and records whether the selected target state remains unchanged.

## Evidence to retain

After each case, save the object returned by:

```js
await __Raqee3NativeFSA.inspect()
```

At the end, export the helper's complete report:

```js
__Raqee3NativeFSA.report()
```

Record the exact browser version, operating system, whether the picker was native, the eight per-case A/B hashes, the application summary/toast, and any permission prompts/errors. A case is a PASS only when B remains at its captured original hash and A has the exact expected state shown in the matrix. Any `other` state is a failure requiring preservation of the files for investigation; do not overwrite it with a reset before recording evidence.

## Cleanup

After evidence is retained, close the tab. The helper restores wrapped methods after each completed transaction. The test files remain on disk; no production file is touched. Stop the local server with Ctrl+C.

## What this test does not establish

- It does not establish production reachability by itself.
- Injected write/close errors are deliberate test faults; they do not claim that a browser natively produces those exact error timings.
- It is a manual test kit and has **not** been executed by the assistant against the user's OS files. Native FSA status must remain `NOT_TESTED` until the operator returns the real-browser logs and A/B hashes.
