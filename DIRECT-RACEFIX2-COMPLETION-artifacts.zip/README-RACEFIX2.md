# Raqee3 v8.0.0 — RC3-DEV RACEFIX2 candidate review package

## Decision

**MOCK-VALIDATED candidate; not release accepted.** This package extends the prior RACEFIX work in two ways:

1. It tests the two asynchronous phases that were not covered by RACEFIX1: a suspended primary `writer.write()` and a suspended primary `writer.close()`. It also forces the global target to B while each operation is pending.
2. It corrects `DIRECT-FB-01`: creation of an alternative download link after a failed or unavailable direct save no longer replaces a warning with a generic green/success download message. The user is told that a link was prepared and that the actual download is not confirmed.

## Candidate identity

- Candidate: `raqee3-v8.0.0-rc3-dev-racefix2.html`
- Size: `495312` bytes
- SHA-256: `6e41866ff757518f641546083e5441e19f153c3585a6b43799fd2daa66561c13`
- Git Blob SHA-1 (computed locally from exact candidate bytes): `9e582fd76b471c51edb91587ce56e2629916f0ec`
- Parent: `raqee3-v8.0.0-rc3-dev-racefix.html`
- Parent SHA-256: `29f454fbf77a3e78336a8ca82ec01843ed8e2dff42a27cd911b5879e85573632`
- RC3-DEV baseline SHA-256: `ebdb9c9f34f09c094d394bda897555758efe7aad9f30e43b41f1bd5fb7b873ed` (unchanged)
- RC2 reference SHA-256: `8b7357295f333a44b861d03d555b86b475df53bc1227b9cb5f195026bd4fda9c` (unchanged)

The source patch is `RACEFIX-to-RACEFIX2.patch`. It is limited to the direct-download fallback status path and the `doDownload` helper/call sites. The prior transaction-pinned handle remediation is retained.

## DIRECT-RACE-01..08 — Chromium acceptance

- Chromium: `144.0.7559.96`
- Independent browser processes: **3**
- Total executions: **42/42 safe**
- Assertions: **504/504 passed**
- Repeatability across independent browser processes: **true**

Coverage:

| Race | Suspended operation | Additional action |
|---|---|---|
| 01 | Freshness read | UI switch attempt / forced target swap |
| 02 | Backup byte read | UI switch attempt / forced target swap |
| 03 | `createWritable()` | UI switch attempt / forced target swap |
| 04 | Post-write readback | UI switch attempt / forced target swap |
| 05 | Primary `write()` pending | UI picker and clear/clean/undo attempts; forced target swap |
| 06 | Primary `close()` pending | UI picker and clear/clean/undo attempts; forced target swap |
| 07 | `write()` fault | Forced swap; mock partially mutates A then rejects; rollback must restore exact A bytes |
| 08 | `close()` fault | Forced swap; mock commits A then rejects; rollback must restore exact A bytes |

In all 42 executions, B retained its original SHA-256 `7402f922922028f2963ed0ed380a7fd65b82529d9b67a67413bd2403cf4800dd`. A was either the expected patched output or was restored exactly to its original SHA-256 `1e32bcc37093e4248951245d92354805ed105172c8a1c50811981cbf6b5ac87b`. Transaction evidence continued to identify A. Target-changing event handlers for file input, clear, clean, and undo were attempted while the transaction was busy and asserted not to mutate the transaction target state.

The injected `write()` and `close()` failures are conservative in-memory fault models. They are not claims about the exact failure semantics of a particular native browser implementation.

## DIRECT-FB-01 — fallback-message regression

- Chromium: `144.0.7559.96`
- Independent browser processes: **3**
- Candidate runs: **18/18 cases passed; 105/105 assertions passed**
- Fallback scenarios: no direct handle; mismatched handle; stale identity before transaction; original exceeds 10 MiB backup limit; backup read failure.
- Ordinary download mode was retained as a success-message control.

The prior RACEFIX1 source was also run as a baseline. Four previously affected branches (no handle, mismatched handle, stale identity, and >10 MiB original) reproduced the false-success summary/toast in **12/12 baseline executions**. The new candidate passed the warning assertions in all corresponding tests and in the backup-read-failure scenario.

## Reproduction

Place the following files in one directory:

- `raqee3-v8.0.0-rc3-dev-racefix2.html`
- `raqee3-v8.0.0-rc3-dev-racefix.html`
- `DIRECT-RACE-01-08-RACEFIX2-harness.py`
- `DIRECT-FB-01-regression.py`
- `NATIVE-FSA-DIRECT-02-harness.js`
- `NATIVE-FSA-MANUAL-TEST.md`
- disposable fixtures `index.html` and `B.txt`

Run the mock/browser regression scripts as shown above. For real Native FSA, follow `NATIVE-FSA-MANUAL-TEST.md` on a desktop Chrome/Edge profile.

Run:

```bash
python DIRECT-RACE-01-08-RACEFIX2-harness.py
python DIRECT-FB-01-regression.py
```

The harnesses use Python Playwright and Chromium. `DIRECT-FB-01-regression.py` compares the candidate with the included parent source. The detailed JSON results contain per-run outcomes and assertions; `A-B-byte-ledger-RACEFIX2.csv` exposes each A/B byte invariant in tabular form.

## Native File System Access handoff kit — prepared, not executed

This package also includes `NATIVE-FSA-MANUAL-TEST.md`, `NATIVE-FSA-DIRECT-02-harness.js`, `index.html`, and `B.txt`. These are a handoff kit for a reviewer/operator on desktop Chrome or Edge. It uses the real application picker and real OS-backed handles, and inserts controlled pauses around native handle/writer operations. It is **not** evidence that Native FSA or physical disk tests have already been run. Run only with the disposable A/B fixtures, follow the manual procedure, and attach the exported `__Raqee3NativeFSA.report()` plus the browser/version and observed hashes. A separate `DIRECT-02-NATIVE-FSA-MANUAL-KIT.zip` packages just these five files and its checksum manifest.

## Static checks and patch verification

- Both inline JavaScript script blocks passed `node --check`.
- Both Python harnesses passed `py_compile`.
- The unified patch applied to a fresh parent copy and reproduced the candidate bytes exactly.
- The Native FSA helper passed `node --check`; the manual procedure and disposable A/B fixtures were packaged for external execution.
- The candidate file was not modified by the browser test runs.
- `NATIVE-FSA-DIRECT-02-harness.js` passed `node --check`; the manual Native FSA kit is prepared but unexecuted.
- `SHA256SUMS.txt` covers all individual package files except itself.

## Limits and non-claims

- Browser execution used actual HTML, DOM and application handlers in Chromium `144.0.7559.96`.
- File A/B and writer behavior used deterministic in-memory `FileSystemFileHandle`-like fixtures.
- Native `showOpenFilePicker()`, native File System Access permission lifecycle, OS file handles, and physical disk writes were **NOT TESTED** in this environment. A manual kit is provided for a desktop operator; creating the kit is not a test result.
- Production reachability remains **UNPROVEN**.
- `DIRECT-02` remains **OPEN**. This package does not authorize closing that finding or promoting this candidate to RC3/release.

## Repository and source preservation

At build time, this operation did not write to GitHub or modify the repository. The RC2 reference and RC3-DEV baseline hashes above were preserved. The uploaded predecessor evidence package remains a separate repository artifact; this candidate package and Native FSA handoff kit are prepared locally for review and have not been uploaded by this operation.

## Current status

- `DIRECT-RACE-01..08`: `VERIFIED_AT_CHROMIUM_MOCK_LEVEL_AFTER_FIX`
- `DIRECT-FB-01`: `VERIFIED_AT_CHROMIUM_MOCK_LEVEL_AFTER_FIX`
- `DIRECT-02`: `OPEN` — native FSA and production reachability pending
- `RC3-DEV-RACEFIX2`: `CANDIDATE — MOCK-VALIDATED`
- Native FSA handoff: `PREPARED — NOT EXECUTED`
- `RC2`: `BLOCKED — FROZEN`
