/*
 * Raqee3 RC3-DEV-RACEFIX2 — native File System Access test helper.
 * Paste into DevTools Console on the locally served candidate HTML.
 * The file picker and underlying FileSystemFileHandle/FileSystemWritableFileStream
 * objects are native. Proxies bind native methods to their original receivers and
 * insert controlled waits/faults around selected calls; file bytes are real disk bytes.
 * Use disposable fixtures only. restoreOriginalA() writes to the selected test file.
 */
(function () {
  'use strict';
  if (!window.directFileHandle || !window.currentFileName) {
    throw new Error('Open the disposable A test file in Raqee3 first, then paste this helper.');
  }
  if (window.__Raqee3NativeFSA && window.__Raqee3NativeFSA.version === '1.0.0') {
    console.warn('Native FSA helper already installed. Reuse window.__Raqee3NativeFSA.');
    return;
  }

  const api = {
    version: '1.0.0',
    targets: Object.create(null),
    activeGate: null,
    armedLabel: null,
    lastUiAttempt: null,
    lastForcedSwap: null,
    lastInspection: null,

    _makeGate(stage, failureMode) {
      let resolveHold, resolveEntered;
      const hold = new Promise(resolve => { resolveHold = resolve; });
      const entered = new Promise(resolve => { resolveEntered = resolve; });
      return {
        stage,
        failureMode: failureMode || null,
        hold,
        entered,
        enter() {
          resolveEntered({ stage, at: new Date().toISOString() });
          return hold;
        },
        release() { resolveHold({ released: true }); }
      };
    },

    async capture(label) {
      if (!['A', 'B'].includes(label)) throw new Error('Label must be A or B.');
      if (!window.directFileHandle || !window.directFileName || window.currentFileName !== window.directFileName) {
        throw new Error('The currently selected direct file must match the current target.');
      }
      try { if (window.currentTargetRawHashPromise) await window.currentTargetRawHashPromise; } catch (_) {}
      const handle = window.directFileHandle;
      const file = await handle.getFile();
      const bytes = new Uint8Array(await file.arrayBuffer());
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      const sha256 = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
      const state = {
        rawHandle: handle,
        handle,
        wrappedHandle: null,
        directFileName: window.directFileName,
        directTargetMatches: window.directTargetMatches,
        directOpenedSnapshot: window.directOpenedSnapshot,
        currentFileName: window.currentFileName,
        currentHtml: window.currentHtml,
        currentLineEnding: window.currentLineEnding,
        currentLineEndings: Array.isArray(window.currentLineEndings) ? window.currentLineEndings.slice() : [],
        currentEncoding: window.currentEncoding,
        currentHasBOM: window.currentHasBOM,
        currentTargetLoadToken: window.currentTargetLoadToken,
        currentTargetRawToken: window.currentTargetRawToken,
        currentTargetRawEvidence: window.currentTargetRawEvidence ? Object.assign({}, window.currentTargetRawEvidence) : null,
        name: file.name,
        size: file.size,
        originalBytes: bytes,
        originalSha256: sha256
      };
      state.rawHashPromise = Promise.resolve(state.currentTargetRawEvidence && state.currentTargetRawEvidence.sha256 || sha256);
      this.targets[label] = state;

      // A is the transaction target and needs a deterministic expected output.
      // B is only a sentinel: do not require the default patch set to match B.txt.
      if (label === 'A') {
        const res = window.applyAllPatches(state.currentHtml, { continueOnFail: false });
        if (!res || !res.outputAccepted || res.aborted) throw new Error('Default patch set did not produce an accepted output for A.');
        const outputText = state.currentLineEndings.length
          ? await window.remapLineEndings(res.html, state.currentHtml, state.currentLineEndings, state.currentLineEnding)
          : window.restoreLineEnding(res.html, state.currentLineEnding);
        const outputBytes = new Uint8Array(window.encodeTextForFile(outputText, state.currentEncoding, state.currentHasBOM));
        const outDigest = await crypto.subtle.digest('SHA-256', outputBytes);
        state.expectedOutputBytes = outputBytes;
        state.expectedOutputSha256 = Array.from(new Uint8Array(outDigest), b => b.toString(16).padStart(2, '0')).join('');
      }
      return {
        label,
        name: state.name,
        size: state.size,
        originalSha256: state.originalSha256,
        expectedPatchedSize: state.expectedOutputBytes ? state.expectedOutputBytes.length : null,
        expectedPatchedSha256: state.expectedOutputSha256 || null,
        role: label === 'A' ? 'transaction-target' : 'untouched-sentinel',
        nativeHandle: true,
        secureContext: window.isSecureContext
      };
    },

    selectState(label) {
      const s = this.targets[label];
      if (!s) throw new Error('Capture target ' + label + ' first.');
      const handle = s.rawHandle || s.handle;
      s.handle = handle;
      s.wrappedHandle = null;
      window.directFileHandle = handle;
      window.directFileName = s.directFileName;
      window.directTargetMatches = s.directTargetMatches;
      window.directOpenedSnapshot = s.directOpenedSnapshot;
      window.currentFileName = s.currentFileName;
      window.currentHtml = s.currentHtml;
      window.currentLineEnding = s.currentLineEnding;
      window.currentLineEndings = s.currentLineEndings.slice();
      window.currentEncoding = s.currentEncoding;
      window.currentHasBOM = s.currentHasBOM;
      window.currentTargetLoadToken = s.currentTargetLoadToken;
      window.currentTargetRawToken = s.currentTargetRawToken;
      window.currentTargetRawEvidence = s.currentTargetRawEvidence ? Object.assign({}, s.currentTargetRawEvidence) : null;
      window.currentTargetRawHashPromise = Promise.resolve(s.rawHashPromise);
      return { selected: label, name: s.name, currentFileName: window.currentFileName };
    },

    async arm(stage) {
      if (window.directWriteBusy) throw new Error('A direct-write transaction is already busy.');
      const s = this.targets.A;
      if (!s) throw new Error('Capture A first.');
      if (window.directFileHandle !== s.rawHandle || window.currentFileName !== s.currentFileName) {
        throw new Error('Reselect A with the real app picker, then run selectState("A") and arm again.');
      }
      this.disarm();
      const allowed = ['freshness-buffer', 'backup-buffer', 'postwrite-buffer', 'createWritable', 'write', 'write-fail', 'close', 'close-after-commit-fail'];
      if (!allowed.includes(stage)) throw new Error('Unsupported stage: ' + stage);

      const gate = this._makeGate(stage, null);
      this.activeGate = gate;
      this.armedLabel = 'A';
      const rawHandle = s.rawHandle;
      const pause = async () => { gate.enter(); await gate.hold; };
      let getFileCalls = 0;
      let createWritableCalls = 0;
      const targetReadCall = stage === 'freshness-buffer' ? 1 : stage === 'backup-buffer' ? 2 : stage === 'postwrite-buffer' ? 3 : -1;

      const wrappedHandle = new Proxy(rawHandle, {
        get(target, property) {
          if (property === 'getFile') {
            return async (...args) => {
              const file = await target.getFile(...args);
              getFileCalls++;
              if (getFileCalls === targetReadCall) {
                return new Proxy(file, {
                  get(fileTarget, fileProperty) {
                    if (fileProperty === 'arrayBuffer') {
                      return async (...bufferArgs) => {
                        await pause();
                        return fileTarget.arrayBuffer(...bufferArgs);
                      };
                    }
                    const value = Reflect.get(fileTarget, fileProperty, fileTarget);
                    return typeof value === 'function' ? value.bind(fileTarget) : value;
                  }
                });
              }
              return file;
            };
          }
          if (property === 'createWritable') {
            return async (...args) => {
              createWritableCalls++;
              if (stage === 'createWritable' && createWritableCalls === 1) await pause();
              const writer = await target.createWritable(...args);
              if (createWritableCalls === 1 && ['write', 'write-fail', 'close', 'close-after-commit-fail'].includes(stage)) {
                return new Proxy(writer, {
                  get(writerTarget, writerProperty) {
                    if (writerProperty === 'write' && ['write', 'write-fail'].includes(stage)) {
                      return async (...writeArgs) => {
                        await pause();
                        if (stage === 'write-fail') {
                          const value = writeArgs[0];
                          if (!(value instanceof Uint8Array)) throw new Error('Native write fault test expected Uint8Array input.');
                          const partial = value.slice(0, Math.max(1, Math.floor(value.length / 2)));
                          await writerTarget.write(partial);
                          throw new Error('NATIVE_TEST_INJECTED_WRITE_FAILURE_AFTER_PARTIAL_STREAM_WRITE');
                        }
                        return writerTarget.write(...writeArgs);
                      };
                    }
                    if (writerProperty === 'close' && ['close', 'close-after-commit-fail'].includes(stage)) {
                      return async (...closeArgs) => {
                        await pause();
                        const result = await writerTarget.close(...closeArgs);
                        if (stage === 'close-after-commit-fail') throw new Error('NATIVE_TEST_INJECTED_CLOSE_FAILURE_AFTER_COMMIT');
                        return result;
                      };
                    }
                    const value = Reflect.get(writerTarget, writerProperty, writerTarget);
                    return typeof value === 'function' ? value.bind(writerTarget) : value;
                  }
                });
              }
              return writer;
            };
          }
          const value = Reflect.get(target, property, target);
          return typeof value === 'function' ? value.bind(target) : value;
        }
      });

      s.handle = wrappedHandle;
      s.wrappedHandle = wrappedHandle;
      window.directFileHandle = wrappedHandle;
      return { armed: true, stage, target: s.name, targetSha256: s.originalSha256, underlyingHandleIsNative: true };
    },

    waitUntilPaused(timeoutMs = 30000) {
      if (!this.activeGate) throw new Error('No active gate.');
      const entered = this.activeGate.entered;
      return Promise.race([
        entered,
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timed out waiting for the native operation to pause. Check the app log and disarm the helper.')), timeoutMs))
      ]);
    },

    release() {
      if (!this.activeGate) throw new Error('No active gate.');
      this.activeGate.release();
      return { released: true, stage: this.activeGate.stage };
    },

    async waitUntilIdle(timeoutMs = 30000) {
      const start = Date.now();
      while (window.directWriteBusy) {
        if (Date.now() - start > timeoutMs) throw new Error('Timed out waiting for directWriteBusy=false.');
        await new Promise(resolve => setTimeout(resolve, 25));
      }
      await new Promise(resolve => setTimeout(resolve, 150));
      this.disarm();
      return { idle: true, at: new Date().toISOString() };
    },

    forceTarget(label) {
      if (!window.directWriteBusy) throw new Error('Run this only while the direct-write transaction is paused and busy.');
      const result = this.selectState(label);
      this.lastForcedSwap = { label, at: new Date().toISOString(), result };
      return this.lastForcedSwap;
    },

    tryUiMutations() {
      if (!window.directWriteBusy) throw new Error('Run this only while directWriteBusy is true.');
      const controls = {
        picker: document.getElementById('openForDirectBtn'),
        input: document.getElementById('targetFile'),
        clear: document.getElementById('clearBtn'),
        clean: document.getElementById('cleanTargetBtn'),
        undo: document.getElementById('undoTargetBtn')
      };
      const savedDisabled = Object.fromEntries(Object.entries(controls).map(([k, el]) => [k, el ? el.disabled : null]));
      const before = { name: window.currentFileName, directName: window.directFileName, handle: window.directFileHandle,
        html: window.currentHtml, loadToken: window.currentTargetLoadToken, rawToken: window.currentTargetRawToken };
      const messages = [];
      const priorToast = window.toast;
      window.toast = function (message) { messages.push(String(message)); return priorToast.apply(this, arguments); };
      try {
        if (controls.picker) { controls.picker.disabled = false; controls.picker.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); }
        if (controls.input) {
          const dt = new DataTransfer(); dt.items.add(new File(['NATIVE-FSA-INPUT-ATTEMPT'], 'input-attempt.html', { type: 'text/html' }));
          controls.input.files = dt.files; controls.input.disabled = false;
          controls.input.dispatchEvent(new Event('change', { bubbles: true }));
        }
        for (const key of ['clear', 'clean', 'undo']) {
          const el = controls[key];
          if (el) { el.disabled = false; el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); }
        }
      } finally {
        window.toast = priorToast;
        for (const [key, el] of Object.entries(controls)) if (el && savedDisabled[key] !== null) el.disabled = savedDisabled[key];
      }
      const after = { name: window.currentFileName, directName: window.directFileName, handle: window.directFileHandle,
        html: window.currentHtml, loadToken: window.currentTargetLoadToken, rawToken: window.currentTargetRawToken };
      this.lastUiAttempt = {
        at: new Date().toISOString(), messages,
        stateUnchanged: before.name === after.name && before.directName === after.directName && before.handle === after.handle &&
          before.html === after.html && before.loadToken === after.loadToken && before.rawToken === after.rawToken,
        selectedName: after.name, handleName: after.handle && after.handle.name,
        pickerInputClearCleanUndoEventsAttempted: true
      };
      return this.lastUiAttempt;
    },

    async inspect() {
      const observations = {};
      for (const label of ['A', 'B']) {
        const s = this.targets[label];
        if (!s) continue;
        const handle = s.rawHandle || s.handle;
        const file = await handle.getFile();
        const bytes = new Uint8Array(await file.arrayBuffer());
        const digest = await crypto.subtle.digest('SHA-256', bytes);
        const sha256 = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
        observations[label] = {
          name: file.name, size: file.size, sha256,
          originalSha256: s.originalSha256, expectedPatchedSha256: s.expectedOutputSha256,
          state: sha256 === s.originalSha256 ? 'original' : (sha256 === s.expectedOutputSha256 ? 'patched' : 'other')
        };
      }
      const evidence = typeof window.evidenceGetQueue === 'function' ? window.evidenceGetQueue().slice(-1)[0] : null;
      this.lastInspection = {
        at: new Date().toISOString(), browser: navigator.userAgent, secureContext: window.isSecureContext,
        nativePickerType: typeof window.showOpenFilePicker, directWriteBusy: window.directWriteBusy,
        observations,
        BByteIdentical: !!(observations.B && observations.B.sha256 === observations.B.originalSha256),
        evidence: evidence ? { targetName: evidence.targetName, saveStatus: evidence.saveStatus,
          actualFileSize: evidence.actualFileSize, actualFileSha256: evidence.actualFileSha256 } : null,
        summary: document.getElementById('summary') ? document.getElementById('summary').innerText : '',
        toast: document.getElementById('toast') ? document.getElementById('toast').innerText : '',
        uiAttempt: this.lastUiAttempt, forcedSwap: this.lastForcedSwap
      };
      return this.lastInspection;
    },

    async restoreOriginalA() {
      const s = this.targets.A;
      if (!s) throw new Error('Capture A first.');
      if (window.directWriteBusy) throw new Error('Cannot restore bytes while directWriteBusy.');
      const handle = s.rawHandle || s.handle;
      const writer = await handle.createWritable();
      await writer.write(s.originalBytes);
      await writer.close();
      const check = await handle.getFile();
      const bytes = new Uint8Array(await check.arrayBuffer());
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      const sha256 = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
      return { restored: sha256 === s.originalSha256, size: bytes.length, sha256 };
    },

    disarm() {
      if (this.armedLabel && this.targets[this.armedLabel]) {
        const s = this.targets[this.armedLabel];
        if (s.wrappedHandle && window.directFileHandle === s.wrappedHandle) window.directFileHandle = s.rawHandle;
        s.handle = s.rawHandle;
        s.wrappedHandle = null;
      }
      this.armedLabel = null;
      this.activeGate = null;
      return { disarmed: true };
    },

    report() {
      return JSON.stringify({
        testKit: 'DIRECT-02-NATIVE-FSA-MANUAL-1.0.0', browser: navigator.userAgent,
        secureContext: window.isSecureContext,
        targets: Object.fromEntries(Object.entries(this.targets).map(([k, s]) => [k, {
          name: s.name, size: s.size, originalSha256: s.originalSha256, expectedPatchedSha256: s.expectedOutputSha256
        }])),
        lastInspection: this.lastInspection, lastUiAttempt: this.lastUiAttempt,
        lastForcedSwap: this.lastForcedSwap, directWriteBusy: window.directWriteBusy
      }, null, 2);
    }
  };

  window.__Raqee3NativeFSA = api;
  console.info('Raqee3 Native FSA helper installed. Select/capture A and B with the REAL application picker.');
  console.info('Examples: await __Raqee3NativeFSA.capture("A"); await __Raqee3NativeFSA.capture("B");');
})();
