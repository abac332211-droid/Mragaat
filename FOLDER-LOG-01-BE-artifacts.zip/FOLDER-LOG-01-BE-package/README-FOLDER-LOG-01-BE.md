# FOLDER-LOG-01-BE — Mock test record

## Outcome

- Runtime: Node.js v22.16.0.
- Independent executions: 3/3 completed with the same behavioral outcomes.
- Per execution: 4/4 cases and 29/29 assertions passed.
- Aggregate: 12/12 case executions and 87/87 assertions passed.
- Finding `FOLDER-LOG-01`: remains `OPEN`.
- Production reachability: `UNPROVEN`.
- Browser integration: `NOT_RUN`.

## Source and provenance

The suite uses the same source-derived excerpts of `folderCreateMockFromFiles()`, `folderResolvePath()`, `folderReadRawBytes()`, `folderBytesEqual()`, and `folderRunWriteBatch()` as the earlier FOLDER-LOG-01-A harness.

Repository reference recorded by the earlier source retrieval:

- Repository: `abac332211-droid/Mragaat`
- Branch: `main`
- File: `raqee3-v8.0.0-rc2-candidate.html`
- Git Blob SHA-1: `914dc7e394b9d87d555852c3faeffb13c6bcfb8f`

No complete RC2 file was materialized for this suite. No RC2 or repository file was edited. The plan and fixtures are synthetic. All writes occur only inside the in-memory mock implementation; no real file system handles or user files are used.

## Cases

| Case | Injected scenario | Expected and observed log status |
|---|---|---|
| B | A write is committed by the mock, then `close()` throws; rollback restores and verifies the original bytes | `recovered` |
| C | A write is committed, then `close()` throws; rollback `createWritable()` also throws | `recovery_failed` |
| D | Two writes are committed; rollback of the later file succeeds and rollback of the earlier file fails | `recovery_partial` |
| E | The first file is written; the next file fails in `beforeWrite`, before it is appended to `attempted`; the first file is then restored | `recovered` |

Each case checks the final file bytes as well as the relevant counters and entry statuses. The repeated runs preserve the same status sequence: `recovered`, `recovery_failed`, `recovery_partial`, `recovered`.

## Case F — not dynamically injected

The source increments `rollbackAttempts` once at the start of each rollback-loop iteration. It increments `rollbackFailures` only from the catch block within that same iteration. Consequently, under the unmodified function's normal control flow:

`0 <= rollbackFailures <= rollbackAttempts`

A state with more rollback failures than rollback attempts, or a corrupted local rollback counter, is not naturally reachable through the exposed mock APIs because both counters are local to `folderRunWriteBatch()`. Forcing such a state would require source instrumentation or altering the function, which would no longer be a faithful test of the supplied source excerpt. Case F is therefore recorded as a defensive source-level review, not as a passed runtime test.

## Browser limitation

A Chromium headless attempt to load the earlier A HTML harness timed out before producing DOM output. A separate minimal `data:` HTML smoke test also timed out in the same Chromium environment. Therefore no browser execution is claimed. The B–E results are Node mock-harness results only.

## Interpretation

B and E demonstrate justified `recovered` outcomes because at least one rollback was attempted and the original bytes were verified. C and D confirm the current failure and partial-recovery branches. These results do not repair or negate A: A still demonstrates the false `recovered` classification when a pre-write failure occurs with zero writes and zero rollback attempts.

This package does not establish production reachability, validate `window.confirm()`, exercise the native File System Access API, or justify closing the finding.
